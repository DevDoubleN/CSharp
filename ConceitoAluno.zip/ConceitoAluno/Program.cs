﻿using System;

namespace ConceitoAluno
{
    public enum Conceito
    {
        A,

        B,

        C,

        D,

        E
    }
    class Program
    {
        public struct Aluno
        {
            public string Nome { get; set; }
            public decimal Nota { get; set; }
        }

        static void Main(string[] args)
        {
            Aluno[] alunos = new Aluno[5];
            var IndiceAluno = 0;
            string OpcaoUsuario = ObterOpcaoUsuario();

            while (OpcaoUsuario.ToUpper() != "X")
            {
                switch (OpcaoUsuario)
                {
                    case "1":
                        Console.WriteLine("Informe o nome do aluno:");
                        Aluno aluno = new Aluno();
                        aluno.Nome = Console.ReadLine();
                        Console.WriteLine("Informe a nota:");
                        if (decimal.TryParse(Console.ReadLine(), out decimal nota))
                        {
                            aluno.Nota = nota;
                        }
                        else
                        {
                            throw new ArgumentException("Valor da nota deve ser decimal");
                        }
                        alunos[IndiceAluno] = aluno;
                        IndiceAluno++;
                        break;

                    case "2":
                        foreach (var a in alunos)
                        {
                            if (!string.IsNullOrEmpty(a.Nome))
                            {
                                Console.WriteLine($"Aluno: {a.Nome} - Nota: {a.Nota}");
                            }
                        }
                        break;

                    case "3":
                        decimal notaTotal = 0;
                        var nmrAlunos = 0;
                        for (int i = 0; i < alunos.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(alunos[i].Nome))
                            {
                                notaTotal = notaTotal + alunos[i].Nota;
                                nmrAlunos++;
                            }
                        }

                        var MediaGeral = notaTotal / nmrAlunos;

                        Conceito ConcGeral;

                        if (MediaGeral < 3)
                        {
                            ConcGeral = Conceito.E;
                        }
                        else if (MediaGeral < 4)
                        {
                            ConcGeral = Conceito.D;
                        }
                        else if (MediaGeral < 6)
                        {
                            ConcGeral = Conceito.C;
                        }
                        else if (MediaGeral < 8)
                        {
                            ConcGeral = Conceito.B;
                        }
                        else
                        {
                            ConcGeral = Conceito.A;
                        }

                        Console.WriteLine($"Média geral: {MediaGeral} - Conceito: {ConcGeral}");
                        break;

                    default:
                        throw new ArgumentOutOfRangeException();
                }

                OpcaoUsuario = ObterOpcaoUsuario();
            }

        }
        private static string ObterOpcaoUsuario()
        {
            Console.WriteLine();
            Console.WriteLine("Informe a opção desejada");
            Console.WriteLine("1 - Inserir novo aluno");
            Console.WriteLine("2 - Listar alunos");
            Console.WriteLine("3 - Calcular média geral");
            Console.WriteLine("X - Sair");
            Console.WriteLine();

            string OpcaoUsuario = Console.ReadLine();
            Console.WriteLine();
            return OpcaoUsuario;
        }
    }
}