﻿using System;

namespace ConsumoCombustivel
{
    class Program
    {
        static void Main(string[] args)
        {
            float consumoMedio, distPercorrida, precoLitroCombustivel, totCombustivelGasto, valorTotalGasto;

            Console.WriteLine("Consumo médio do veículo:");
            consumoMedio = float.Parse(Console.ReadLine());
            Console.WriteLine("Distância percorrida:");
            distPercorrida = float.Parse(Console.ReadLine());
            Console.WriteLine("Preço do combustível por litro:");
            precoLitroCombustivel = float.Parse(Console.ReadLine());

            totCombustivelGasto = distPercorrida / consumoMedio;
            valorTotalGasto = totCombustivelGasto * precoLitroCombustivel;

            Console.WriteLine("Este é o consumo médio do veículo: {0}", consumoMedio);
            Console.WriteLine("Esta é a distância percorrida: {0}", distPercorrida);
            Console.WriteLine("Este é o preço do combustivel por litro: {0}", precoLitroCombustivel);
            Console.WriteLine("Valor total gasto: R$ {0:f}", valorTotalGasto);
        }
    }
}