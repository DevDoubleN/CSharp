﻿using System;

namespace OperadorTernario
{
    class Program
    {
        static void Main(string[] args)
        {
            int idade = 0;
            Console.WriteLine("Informe a idade:");
            idade = int.Parse(Console.ReadLine());
            double preco = 4.05;

            double passagem = idade < 65 ? preco : preco - preco;

            Console.WriteLine(idade < 65 ? "O passageiro irá pagar R$" + passagem + " na passagem." : "O passageiro está isento do pagamento!");
        }
    }
}
