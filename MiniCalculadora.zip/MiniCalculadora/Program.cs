﻿using System;

namespace MiniCalculadora
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string a, b, resp;
            double a2, b2, tot;

            Console.WriteLine("Bem-vindo à calculadora");
            a = Console.ReadLine();
            a2 = double.Parse(a);
            resp = Console.ReadLine();
            switch (resp)
            {
                case "+":
                    b = Console.ReadLine();
                    b2 = double.Parse(b);
                    tot = a2 + b2;
                    Console.WriteLine("----------------");
                    Console.WriteLine(tot);
                    break;

                case "-":
                    b = Console.ReadLine();
                    b2 = double.Parse(b);
                    tot = a2 - b2;
                    Console.WriteLine("----------------");
                    Console.WriteLine(tot);
                    break;

                case "*":
                    b = Console.ReadLine();
                    b2 = double.Parse(b);
                    tot = a2 * b2;
                    Console.WriteLine("----------------");
                    Console.WriteLine(tot);
                    break;

                case "/":
                    b = Console.ReadLine();
                    b2 = double.Parse(b);
                    tot = a2 / b2;
                    Console.WriteLine("----------------");
                    Console.WriteLine(tot);
                    break;
                default:
                    Console.WriteLine("Operação não reconhecida! Selecione novamente:");
                    resp = Console.ReadLine();
                    break;
            }
        }
    }
}
