﻿using System;

namespace WhileSimples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string correctpassword = "admin";
            string password;
            int tentativa = 1;

            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("================= BEM-VINDO ==================");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("----------------------------------------------");

            Console.WriteLine("Digite a senha de acesso:");
            password = Console.ReadLine();

            while(password != correctpassword)
            {
                if (password != correctpassword)
                {
                    Console.Clear();
                    Console.WriteLine("Senha incorreta! Tente novamente.");
                }

                Console.WriteLine("Digite a senha de acesso:");
                password = Console.ReadLine();
                tentativa++;

                if (tentativa == 3)
                {
                    Console.WriteLine("Tentativas encerradas!!");
                    break;
                }
            }
        }
    }
}
