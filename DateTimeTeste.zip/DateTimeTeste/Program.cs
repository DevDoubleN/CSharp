﻿using System;

namespace DateTimeTeste
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Assinatura a = new Assinatura
            {
                Codigo = 123,
                Nome = "Produto de teste",
                Preco = 100.00M,
                DataExpiracao = DateTime.Today.AddMonths(12)
            };
            Console.WriteLine(a.Codigo + "\n" + a.Nome + "\n" + a.Preco + "\n");
            Console.WriteLine($"Dias restantes de assinatura: {a.GetTempoRestante().Days}");
        }
    }
}
