﻿using System;

namespace DateTimeTeste
{
    public class Assinatura : Produto
    {
        private DateTime dataExpiracao;
        public DateTime DataExpiracao { get => dataExpiracao; set => dataExpiracao = value; }
        public TimeSpan GetTempoRestante()
        {
            return dataExpiracao - DateTime.Today;
        }
    }
}
